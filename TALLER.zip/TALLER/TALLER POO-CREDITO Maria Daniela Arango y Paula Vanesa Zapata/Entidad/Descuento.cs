﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class Descuento : ClienteOro
    {
        public int PorcentajeDescuento { get; set; }
        //public List<Almacen> Almacenes { get; set; }

    }
}
