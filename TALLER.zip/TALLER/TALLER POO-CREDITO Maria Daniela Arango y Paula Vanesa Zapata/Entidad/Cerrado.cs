﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class Cerrado : Credito
    {
        public int MontoDineroCancelado { get; set; } == public int MontoTotalCredito { get; set; }

    }
}
